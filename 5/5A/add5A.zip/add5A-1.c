#include<stdio.h>
int main()
{
    printf("One World,One Economic!");
    return 0;
}