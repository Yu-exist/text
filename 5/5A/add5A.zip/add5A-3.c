#include <stdio.h>
int main() 
//通过多行printf实现
{
    printf("  A\n");
    printf(" B C\n");
    printf("D E F\n");
    return 0;
}
